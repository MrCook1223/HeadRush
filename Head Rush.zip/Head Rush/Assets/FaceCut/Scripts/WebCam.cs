﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class WebCam : MonoBehaviour
{

    public WebCamTexture wct;
    public Texture2D maskTexture;
    public Texture2D sampleTexture331x331;
    public Renderer FaceMappingPanel;
    public GameObject resetStart;
    public GameObject Cut;

    void Start()
    {

        if (Application.platform == RuntimePlatform.Android)
        {

            WebCamDevice[] devices = WebCamTexture.devices;

            foreach (WebCamDevice cam in devices)
            {
                if (cam.isFrontFacing)
                {
                    wct = new WebCamTexture(cam.name, Screen.height, Screen.width, 12);
                    wct.deviceName = cam.name;
                    if (wct != null)
                    {
                        FaceMappingPanel.material.mainTexture = wct;
                        wct.Play();
                    }
                }
            }
        }
        else
        {
            WebCamDevice[] devices = WebCamTexture.devices;
            string deviceName = devices[0].name;
            wct = new WebCamTexture(deviceName, Screen.height, Screen.width, 12);
            if (wct != null)
            {
                FaceMappingPanel.material.mainTexture = wct;
                wct.Play();
            }
        }

    }


    public void CutOutFace()
    {
        //Pavziraj kamero
        wct.Pause();

        // Ustvari nov objekt texture2d z enako višino in širino
        Texture2D destTexture = new Texture2D(wct.width, wct.height, TextureFormat.ARGB32, false);
        // pridobi pixle iz kamere
        Color[] textureData = wct.GetPixels();


        destTexture.SetPixels(textureData);
        destTexture.Apply();

        TextureScale.Bilinear(destTexture, 331, 331);

        textureData = destTexture.GetPixels();

        // Ustvari novo sliko 331 x 331
        sampleTexture331x331.SetPixels(textureData);
        sampleTexture331x331.Apply();



        Color[] maskPixels = maskTexture.GetPixels();
        Color[] curPixels = sampleTexture331x331.GetPixels();

        //Sprehodi se skozi masko odstrani vse piksle ki so enaki 0
        int index = 0;
        for (int y = 0; y < maskTexture.height; y++)
        {
            for (int x = 0; x < maskTexture.width; x++)
            {
                if (maskPixels[index] == maskPixels[0])
                {
                    curPixels[index] = Color.clear;
                }
                index++;
            }
        }
        sampleTexture331x331.SetPixels(curPixels, 0);
        sampleTexture331x331.Apply(false);
        FaceMappingPanel.material.mainTexture = sampleTexture331x331;
    }
   




    public void restartCamera()
    {
        FaceMappingPanel.material.mainTexture = wct;
        wct.Play();
        Cut.SetActive(true);
        resetStart.SetActive(false);
    }

    public void cutFace()
    {
        CutOutFace();
        wct.Stop();
        Cut.SetActive(false);
        resetStart.SetActive(true);
    }
    public void MainMenu()
    {
        wct.Stop();
        Initiate.Fade("MainMenu", Color.white, 2.0f);
    }

}
